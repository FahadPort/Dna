<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $__env->yieldContent('title', 'My Website'); ?></title>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<?php echo $__env->yieldPushContent('styles'); ?> <!-- Additional CSS -->
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->yieldPushContent('scripts'); ?> <!-- Additional JavaScript -->


 <!-- Bootstrap CSS -->
 <link rel="stylesheet" href="css/custom.css">
 <link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/slick.css">
 <link rel="stylesheet" href="css/slick-theme.css">
 <link rel="stylesheet" href="css/fancybox.min.css">
<?php /**PATH C:\xampp01\htdocs\dna\resources\views/layouts/head.blade.php ENDPATH**/ ?>