<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Default Title'); ?></title>
   <!-- Add your CSS links here -->
   <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('css/slick-theme.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('css/fancybox.min.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
   <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
   
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

 
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Optional header file -->

    <main>
        <?php echo $__env->yieldContent('content'); ?> <!-- Main content goes here -->
    </main>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Optional footer file -->

    <!-- Add your scripts here -->
    <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fontawesome.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
     <!-- AOS JS -->
     <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    

     <script>
         // Initialize AOS
         AOS.init({
    duration: 1500, // Optional global override
    once: true, // Animates only once on scroll
});

     </script>

    <?php echo $__env->yieldPushContent('scripts'); ?> <!-- Allows injecting additional scripts -->
</body>
</html>
<?php /**PATH C:\xampp01\htdocs\dna\resources\views/layouts/app.blade.php ENDPATH**/ ?>