<Section id="header">

{{-- Top Bar Start  --}}
<div class="container">
<div class="top-bar">
   <ul>
       <li>000 - 123 - 456789</li>
       <li><a href="mailto:info@example.com">info@example.com</a></li>
       <li>No: 58 A, East Lorem Street, Ipsum dolor, MD, USA 4508</li>
   </ul>
</div>
</div>
{{-- Top Bar End  --}}

<!-- Header Start -->


<header>


   <div class="container">
    <nav id='cssmenu'>
    <div class="logo"><a href="index.html"><img src="./images/logo.png" alt=""> </a></div>
    <div id="head-mobile"></div>
    <div class="button"></div>
    <ul class="hdr-menu">
    <li class='active'><a href='#'>HOME</a></li>
    <li><a href='#'>ABOUT</a></li>
    <li><a href='#'>Fees</a></li>
    <li><a href='#'>Services</a></li>
    <li><a href='#'>Contact</a></li>
    <li><a href='#' class="cta-btn">
      <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
         <path d="M17.2905 18.3359C15.2071 18.3359 13.1488 17.8819 11.1155 16.9739C9.08212 16.0659 7.23212 14.7783 5.56545 13.1109C3.89879 11.4436 2.61145 9.59361 1.70345 7.56094C0.795454 5.52827 0.341121 3.46994 0.340454 1.38594C0.340454 1.08594 0.440454 0.835937 0.640454 0.635937C0.840454 0.435937 1.09045 0.335938 1.39045 0.335938H5.44045C5.67379 0.335938 5.88212 0.415271 6.06545 0.573937C6.24879 0.732604 6.35712 0.919937 6.39045 1.13594L7.04045 4.63594C7.07379 4.9026 7.06545 5.1276 7.01545 5.31094C6.96545 5.49427 6.87379 5.6526 6.74045 5.78594L4.31545 8.23594C4.64879 8.8526 5.04445 9.44827 5.50245 10.0229C5.96045 10.5976 6.46479 11.1519 7.01545 11.6859C7.53212 12.2026 8.07379 12.6819 8.64045 13.1239C9.20712 13.5659 9.80712 13.9699 10.4405 14.3359L12.7905 11.9859C12.9405 11.8359 13.1365 11.7236 13.3785 11.6489C13.6205 11.5743 13.8578 11.5533 14.0905 11.5859L17.5405 12.2859C17.7738 12.3526 17.9655 12.4736 18.1155 12.6489C18.2655 12.8243 18.3405 13.0199 18.3405 13.2359V17.2859C18.3405 17.5859 18.2405 17.8359 18.0405 18.0359C17.8405 18.2359 17.5905 18.3359 17.2905 18.3359Z" fill="white"/>
         </svg>
      <span>Emergency call</span> </a></li>
   
    </ul>
    </nav>
   </div>
    </header>
    <!-- Header End -->
   </Section>